import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeStatusComponent } from './trainee-status.component';

describe('TraineeStatusComponent', () => {
  let component: TraineeStatusComponent;
  let fixture: ComponentFixture<TraineeStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TraineeStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TraineeStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
