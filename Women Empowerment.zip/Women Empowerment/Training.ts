export class Training{
    // trainingId:number=0;
    location:string="";
    ngoname:string="";
    courseid:number=0;
    userid:number=0;

}