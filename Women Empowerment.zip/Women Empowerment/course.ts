export class Course{
    courseid: number=0;
    courseName: string="";
    description: string="";
    duration: string="";
    ngoId: number=0;
}