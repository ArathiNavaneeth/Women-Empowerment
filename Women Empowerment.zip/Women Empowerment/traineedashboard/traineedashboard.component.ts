import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-traineedashboard',
  templateUrl: './traineedashboard.component.html',
  styleUrls: ['./traineedashboard.component.css']
})
export class TraineedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
