export class Trainee{
userId:number=0;
fullName:String="";
dob:String="";
gender:String="";
contactNumber:number=0;
emailID:String="";
address:String="";
aadharNumber:number=0;
password:String="";
status:String="";
}
